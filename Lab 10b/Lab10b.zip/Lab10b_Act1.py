# By submitting this assignment, I agree to the following:
#   "Aggies do not lie, cheat, or steal, or tolerate those who do."
#   "I have not given or received any unauthorized aid on this assignment."
#
# Name:         JP Moore
# Section:      519
# Assignment:   Lab 10b-Act1
# Date:         17 November 2021
#

import numpy as np
import matplotlib.pyplot as plt

point = np.array([1, 0])
m2x2 = np.array([[1.00583, -0.087156], [0.087156, 1.00583]]) #given starting "seed" thingie
xs = [point[0]]
ys = [point[1]]

for i in range(250): #generates 50 points by multiplying the seed matrix by the previous point
    point = m2x2 @ point # @: matrix multiplication. What is matrix multiplication? I don't know. 
    xs.append(point[0])
    ys.append(point[1])

plt.title("Swirl")
plt.xlabel("x")
plt.ylabel("y")
plt.plot(xs, ys) #graphing y on the y axis, and x on the x axis. Groundbreaking stuff.
plt.show()